CREATE DATABASE  IF NOT EXISTS `mm_cpsc502102team03` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mm_cpsc502102team03`;
-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: cs100    Database: mm_cpsc502102team03
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `PointCollection`
--

DROP TABLE IF EXISTS `PointCollection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PointCollection` (
  `PointCollectionID` int NOT NULL,
  `Category` varchar(45) DEFAULT NULL,
  `Points` int DEFAULT NULL,
  `UserID` int DEFAULT NULL,
  PRIMARY KEY (`PointCollectionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PointCollection`
--

LOCK TABLES `PointCollection` WRITE;
/*!40000 ALTER TABLE `PointCollection` DISABLE KEYS */;
INSERT INTO `PointCollection` VALUES (1,'Team win',18,2),(2,'Team win',18,4),(3,'Team win',24,5),(4,'Team win',7,8),(5,'Team win ',8,10),(6,'Team win',7,12),(7,'Team win',25,14),(8,'Team win',22,15),(9,'Team win',9,18),(10,'Team win',20,20),(11,'Team win',16,21),(12,'Team win',20,23),(13,'Team win',20,27),(14,'Team win',17,29),(15,'Team win',20,31),(16,'Team win',20,32),(17,'Team win',12,34),(18,'Team win',23,36),(19,'Team win',9,39),(20,'Team win',21,41),(21,'Team win',6,43),(22,'Team win',24,45),(23,'Team win',31,48),(24,'Team win',14,50),(25,'Team win',15,52),(26,'Team win',8,53),(27,'Team win',24,56),(28,'Team win',9,58),(29,'Team win',7,61),(30,'Team win',23,64),(31,'Team win',22,66),(32,'Team win',25,68),(33,'Team win',22,70),(34,'Team win',6,71),(35,'Team win',11,73),(36,'Team win',15,76),(37,'Team win',7,78),(38,'Team win',11,79),(39,'Team win',28,82),(40,'Team win',37,84),(41,'Team win',9,85),(42,'Team win',11,88),(43,'Team win',23,89),(44,'Team win',5,92),(45,'Team win',28,95),(46,'Team win',15,97),(47,'Team win',7,99),(48,'Team win',22,100),(49,'Team win',7,102),(50,'Team win',19,104);
/*!40000 ALTER TABLE `PointCollection` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-25 11:24:44
