CREATE DATABASE  IF NOT EXISTS `mm_cpsc502102team03` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mm_cpsc502102team03`;
-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: cs100    Database: mm_cpsc502102team03
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Teacher`
--

DROP TABLE IF EXISTS `Teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Teacher` (
  `TeacherID` int NOT NULL,
  `TeacherName` varchar(45) DEFAULT NULL,
  `TeacherEmail` varchar(45) DEFAULT NULL,
  `TeacherPassword` varchar(45) DEFAULT NULL,
  `LeagueID` int NOT NULL,
  `AdministratorID` int NOT NULL,
  PRIMARY KEY (`TeacherID`,`LeagueID`),
  KEY `fk_Teacher_League1_idx` (`LeagueID`),
  KEY `fk_Teacher_Administrator1_idx` (`AdministratorID`),
  CONSTRAINT `fk_Teacher_Administrator1` FOREIGN KEY (`AdministratorID`) REFERENCES `Administrator` (`AdministratorID`),
  CONSTRAINT `fk_Teacher_League1` FOREIGN KEY (`LeagueID`) REFERENCES `League` (`LeagueID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Teacher`
--

LOCK TABLES `Teacher` WRITE;
/*!40000 ALTER TABLE `Teacher` DISABLE KEYS */;
INSERT INTO `Teacher` VALUES (1,'Ellene Burdin','eburdin0@bloglines.com','cmaik7',1,15),(2,'Clovis Blythe','cblythe1@bloglines.com','Q3uTqYFyLyS',2,15),(3,'Wally Reina','wreina2@shareasale.com','TbMJG54',3,1),(4,'Tilda Yellop','tyellop3@redcross.org','UjAbLa8jz0K5',4,1),(5,'Abrahan McKeand','amckeand4@wix.com','FrmR1L6a3',5,1),(6,'Antonetta Mikalski','amikalski5@chron.com','dIo2IN8Sp',6,2),(7,'Nobie Bolter','nbolter6@economist.com','jvn1a3i9',7,2),(8,'Margalo Freiburger','mfreiburger7@w3.org','ycZoTG9CNO',8,3),(9,'Ira Ilieve','iilieve8@dagondesign.com','75gp4PORqsg0',9,4),(10,'Halli Redler','hredler9@tinyurl.com','K5i4OCuJ46lB',10,4),(11,'Marijn Klimes','mklimesa@si.edu','JOHjLk',11,4),(12,'Cristin Mansion','cmansionb@weebly.com','pHXyHPXZzT',12,5),(13,'Denni Yurivtsev','dyurivtsevc@boston.com','YgPOQ2',13,6),(14,'Cherri Kitteringham','ckitteringhamd@instagram.com','KUROXLNsoC',14,7),(15,'Jennine Rodmell','jrodmelle@angelfire.com','sQR4n1T7pHzR',15,5),(16,'Ali Eton','aetonf@huffingtonpost.com','7UBL3TSu',16,5),(17,'Lothario Kenafaque','lkenafaqueg@cbslocal.com','ZX98mj',17,5),(18,'Zea Dibling','zdiblingh@engadget.com','OxuZQVo',18,6),(19,'Freddie Dunridge','fdunridgei@furl.net','Xd1HVOu',19,7),(20,'Joaquin Raiment','jraimentj@360.cn','kJUIICyqDc6',20,7),(21,'Casey L\'Hommee','clhommeek@sakura.ne.jp','SDlCYvAUL3L',21,8),(22,'Lauri Marquis','lmarquisl@altervista.org','SNXt05dVD',22,8),(23,'Berton Sanpere','bsanperem@dropbox.com','WaJFV7bzKh',23,10),(24,'Ailyn Stockport','astockportn@wix.com','SoxcUIf',24,10),(25,'Gordy Couronne','gcouronneo@bbc.co.uk','d0SI8tCMtQ',25,9),(26,'Adolf Giacomazzo','agiacomazzop@harvard.edu','M1UWKpkisbFI',26,9),(27,'Billie Corsan','bcorsanq@google.es','iUJHHQ',27,8),(28,'Hobey Antoszczyk','hantoszczykr@yandex.ru','AIpciL3iB8Op',28,11),(29,'Gisela Pendrid','gpendrids@businessinsider.com','QfmpsZ',29,12),(30,'Maridel Summerley','msummerleyt@twitpic.com','qXFCSa',30,12),(31,'Dar Everil','deverilu@marketwatch.com','o0Zxml',31,14),(32,'Prudence Tetlow','ptetlowv@joomla.org','SetoAgQipd',32,13),(33,'Brod Chell','bchellw@instagram.com','YbAZocyjz6',33,14),(34,'Brook Nanelli','bnanellix@jigsy.com','VeS79O3gsWiu',34,13),(35,'Berty Lough','bloughy@vk.com','kj9cfyha',35,13),(36,'Benetta Casperri','bcasperriz@slate.com','xQbc7jV',36,13),(37,'Loretta Pagin','lpagin10@discuz.net','H1qEeOft',37,12),(38,'Laney Limer','llimer11@cargocollective.com','45u0XCD6',38,12),(39,'Marjy Digginson','mdigginson12@disqus.com','BS0CbCXj',39,12),(40,'Biddy Cousins','bcousins13@forbes.com','qo5oxF9',40,12),(41,'Dave Lilbourne','dlilbourne14@symantec.com','PqZ2OIKsaG',41,1),(42,'Jarvis Naden','jnaden15@xrea.com','feDeJ26c',42,1),(43,'Agnesse Polson','apolson16@google.de','HlyWRa6tWveZ',43,1),(44,'Sapphira Niese','sniese17@house.gov','cDFsbeBBa',44,2),(45,'Joletta Barnbrook','jbarnbrook18@bbb.org','E9b2FYord',45,9),(46,'Kinny Rammell','krammell19@histats.com','Q5S4edoQC3',46,8),(47,'Willy Dudson','wdudson1a@xinhuanet.com','hjrORVUkT',47,11),(48,'Austina Zannetti','azannetti1b@flavors.me','T1DDTYjaAZ',48,11),(49,'Ginny Kempston','gkempston1c@google.pl','BBRhReJc',49,7),(50,'Auberon Zettoi','azettoi1d@ebay.co.uk','Ibp78MQ3uP',50,10);
/*!40000 ALTER TABLE `Teacher` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-25 11:24:36
