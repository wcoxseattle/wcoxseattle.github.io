CREATE DATABASE  IF NOT EXISTS `mm_cpsc502102team03` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mm_cpsc502102team03`;
-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: cs100    Database: mm_cpsc502102team03
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Team`
--

DROP TABLE IF EXISTS `Team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Team` (
  `TeamID` int NOT NULL,
  `TeamName` varchar(45) NOT NULL,
  `NumPlayers` int NOT NULL,
  `UserID` int NOT NULL,
  PRIMARY KEY (`TeamID`,`UserID`),
  UNIQUE KEY `TeamID_UNIQUE` (`TeamID`),
  UNIQUE KEY `TeamName_UNIQUE` (`TeamName`),
  KEY `fk_Team_User1_idx` (`UserID`),
  CONSTRAINT `fk_Team_User1` FOREIGN KEY (`UserID`) REFERENCES `User` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Team`
--

LOCK TABLES `Team` WRITE;
/*!40000 ALTER TABLE `Team` DISABLE KEYS */;
INSERT INTO `Team` VALUES (1,'Topicshots',10,1),(2,'Kwilith',10,2),(3,'Babbleset',10,3),(4,'Devpoint',10,4),(5,'Thoughtblab',10,5),(6,'Ozu',10,6),(7,'Photobug',10,7),(8,'Zoonder',10,8),(9,'Chatterbridge',10,9),(10,'Yodo',10,10),(11,'Quinu',10,11),(12,'Geba',10,12),(13,'Thoughtstorm',10,13),(14,'Zoozzy',10,14),(15,'Oyonder',10,15),(16,'Yambee',10,16),(17,'DabZ',10,17),(18,'Avamba',10,18),(19,'Eabox',10,19),(20,'Flipopia',10,20),(21,'Quaxo',10,21),(22,'Skippad',10,22),(23,'Riffwire',10,23),(24,'Meezzy',10,24),(25,'Realfire',10,25),(26,'Photolist',10,26),(27,'Zooxo',10,27),(28,'MooColo',10,28),(29,'Yakidoo',10,29),(30,'Twinte',10,30),(31,'Wikibox',10,31),(32,'Mycat',10,32),(33,'Zoonoodle',10,33),(34,'Feedmix',10,34),(35,'Skaboo',10,35),(36,'Youbridge',10,36),(37,'Photofeed',10,37),(38,'Browseblab',10,38),(39,'Chatterpoint',10,39),(40,'Snaptags',10,40),(41,'Cowspirit',10,41),(42,'Linkbuzz',10,42),(43,'Chipgalore',10,43),(44,'Fivechat',10,44),(45,'Bluejam',10,45),(46,'Wordify',10,46),(47,'Riffpath',10,47),(48,'Aivee',10,48),(49,'Oyondu',10,49),(50,'Edgeify',10,50),(51,'Gevee',10,51),(52,'Browsetype',10,52),(53,'Gigaclub',10,53),(54,'Skyba',10,54),(55,'Gabtune',10,55),(56,'Omba',10,56),(58,'Bubblemix',10,58),(59,'Meeveo',10,59),(60,'Ntags',10,60),(61,'Browsezoom',10,61),(62,'Jatri',10,62),(63,'Trupe',10,63),(64,'Nugentattire',10,64),(65,'Mynte',10,65),(66,'Careberrie',10,66),(67,'Chlorideself',10,67),(68,'Zazio',10,68),(69,'Dripage',10,69),(70,'Cheric',10,70),(71,'Leenti',10,71),(72,'Dabshots',10,72),(73,'Yombu',10,73),(74,'Jetwire',10,74),(75,'Ntag',10,75),(76,'Fadeo',10,76),(77,'Nevernull',10,77),(78,'Realmix',10,78),(79,'Eazzy',10,79),(80,'Blognation',10,80),(81,'Intargumenter',10,81),(82,'Kanoodle',10,82),(83,'Gigazoom',10,83),(84,'Linklinks',10,84),(85,'Shufflebeat',10,85),(86,'Jaloo',10,86),(87,'Brainbox',10,87),(88,'Oozz',10,88),(89,'Looperator',10,89),(90,'Meedoo',10,90),(91,'Mybuzz',10,91),(92,'Edgewire',10,92),(93,'Rhyzio',10,93),(94,'Buzzshare',10,94),(95,'Realpoint',10,95),(96,'Brainsphere',10,96),(97,'Eare',10,97),(98,'Brainverse',10,98),(99,'Vidoo',10,99),(100,'Voomm',10,100),(101,'Voolith',10,101),(102,'Minyx',10,102),(103,'Meexit',10,103),(104,'Intelligent',10,104),(105,'Digitube',10,105),(106,'Aimbu',10,106),(107,'Ooba',10,107),(108,'Kare',10,108),(109,'Meetz',10,109),(111,'Oyoba',10,111),(112,'Skimia',10,112),(113,'Skyndu',10,113),(114,'Oba',10,114),(116,'Skyvu',10,116),(117,'Livepath',10,117),(118,'Roomm',10,118),(120,'Quimm',10,120),(122,'Wikizz',10,122),(123,'Browsebug',10,123),(124,'Yadel',10,124),(125,'Tagopia',10,125),(126,'Yabox',10,126),(127,'Topdrive',10,127),(130,'Eire',10,130),(131,'Jamia',10,131),(132,'Browsecat',10,132),(133,'Skinte',10,133),(134,'Trunyx',10,134),(135,'Thoughtbeat',10,135),(136,'Blogspan',10,136),(137,'Tagfeed',10,137),(138,'Aibox',10,138),(139,'Trudoo',10,139),(140,'Gabcube',10,140),(141,'Latz',10,141),(143,'Flashdog',10,143),(145,'Skiba',10,145),(146,'Brightdog',10,146),(147,'Shuffledrive',10,147),(149,'Jaxnation',10,149),(150,'Dabtype',10,150),(151,'Gabvine',10,151),(152,'Zoombeat',10,152),(154,'Tambee',10,154),(155,'Yakitri',10,155),(156,'Zoovu',10,156),(157,'Yacero',10,157),(158,'Aimbo',10,158),(159,'Voonte',10,159),(162,'Reallinks',10,162),(163,'Rhynyx',10,163),(164,'Mymm',10,164),(165,'Zooveo',10,165),(166,'Kwideo',10,166),(169,'Centizu',10,169),(170,'Lazzy',10,170),(171,'Viva',10,171),(172,'Buzzdog',10,172),(173,'Youfeed',10,173),(174,'Eadel',10,174),(176,'Oyoloo',10,176),(177,'Centimia',10,177),(179,'Gabtype',10,179),(182,'Thoughtmix',10,182),(184,'Thoughtsphere',10,184),(185,'Youspan',10,185),(186,'Devbug',10,186),(188,'Trilith',10,188),(189,'Livetube',10,189),(190,'Browsedrive',10,190),(191,'Thoughtbridge',10,191),(194,'Edgeblab',10,194),(195,'Jabbersphere',10,195),(196,'Eamia',10,196),(197,'Twitterbeat',10,197),(198,'Quatz',10,198),(199,'Linkbridge',10,199),(202,'Ainyx',10,202),(205,'Dablist',10,205),(206,'Zoomcast',10,206),(207,'Skinder',10,207),(208,'Skivee',10,208),(209,'Divanoodle',10,209),(210,'Divavu',10,210),(212,'Agivu',10,212),(213,'Zoomzone',10,213),(214,'Gigashots',10,214),(215,'Talane',10,215),(216,'Rhyloo',10,216),(218,'Jayo',10,218),(219,'Kamba',10,219),(220,'Topiczoom',10,220),(222,'Gabspot',10,222),(224,'Brightbean',10,224),(227,'Yozio',10,227),(229,'Feedbug',10,229),(232,'Jabberstorm',10,232),(234,'Avaveo',10,234),(236,'InnoZ',10,236),(239,'Vipe',10,239),(240,'Tagpad',10,240),(243,'Meevee',10,243),(245,'Mita',10,245),(251,'Vimbo',10,251),(252,'Dynabox',10,252),(258,'JumpXS',10,258),(260,'Avamm',10,260),(263,'Twimm',10,263),(264,'Edgetag',10,264),(265,'Cogidoo',10,265),(267,'Teklist',10,267),(268,'Cogibox',10,268),(269,'Twinder',10,269),(271,'Flashspan',10,271),(273,'Demivee',10,273),(274,'Photospace',10,274),(276,'Realcube',10,276),(277,'Wordtune',10,277),(281,'Innojam',10,281),(282,'Kwimbee',10,282),(286,'Camimbo',10,286),(287,'Janyx',10,287),(290,'Twitternation',10,290),(293,'Jaxbean',10,293),(298,'Skynoodle',10,298),(300,'Rhynoodle',10,300),(303,'Rhybox',10,303),(307,'Lajo',10,307),(310,'Tanoodle',10,310),(312,'Mudo',10,312),(313,'Fanoodle',10,313),(318,'Demizz',10,318),(320,'Dazzlesphere',10,320),(323,'Feedfire',10,323),(324,'Myworks',10,324),(326,'Plambee',10,326),(328,'Voonyx',10,328),(329,'Buzzster',10,329),(332,'Brainlounge',10,332),(333,'Podcat',10,333),(335,'Bubblebox',10,335),(338,'Quimba',10,338),(340,'Tekfly',10,340),(341,'Abata',10,341),(343,'Blogtags',10,343),(344,'Centidel',10,344),(346,'Jabbercube',10,346),(348,'Youopia',10,348),(351,'Flipstorm',10,351),(356,'Fiveclub',10,356),(359,'Oyope',10,359),(360,'Babbleopia',10,360),(362,'Yoveo',10,362),(363,'Yakijo',10,363),(364,'Trilia',10,364),(369,'Feedspan',10,369),(371,'Devshare',10,371),(375,'Skidoo',10,375),(376,'Miboo',10,376),(387,'Roombo',10,387),(388,'Topiclounge',10,388),(392,'Katz',10,392),(394,'Zoomlounge',10,394),(401,'Twitterbridge',10,401),(405,'Feednation',10,405),(406,'Kimia',10,406),(413,'Yamia',10,413),(414,'Mydo',10,414),(416,'Zava',10,416),(417,'Leexo',10,417),(419,'Skipstorm',10,419),(421,'Riffpedia',10,421),(426,'Eimbee',10,426),(428,'Voonix',10,428),(431,'Innotype',10,431),(432,'Babbleblab',10,432),(434,'Photobean',10,434),(437,'Wordware',10,437),(441,'Voolia',10,441),(446,'Photojam',10,446),(447,'Edgeclub',10,447),(452,'Avavee',10,452),(453,'Jetpulse',10,453),(455,'Twitterlist',10,455),(456,'Babblestorm',10,456),(457,'Muxo',10,457),(463,'Fivespan',10,463),(466,'Realbuzz',10,466),(471,'Izio',10,471),(474,'Livefish',10,474),(478,'Dabvine',10,478),(479,'Meejo',10,479),(485,'Topicblab',10,485),(487,'Topicstorm',10,487),(489,'Rooxo',10,489),(496,'Pixonyx',10,496),(497,'Skinix',10,497),(499,'Youtags',10,499);
/*!40000 ALTER TABLE `Team` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-25 11:23:56
