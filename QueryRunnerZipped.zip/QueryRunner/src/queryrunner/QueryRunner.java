/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queryrunner;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * 
 * QueryRunner takes a list of Queries that are initialized in it's constructor
 * and provides functions that will call the various functions in the QueryJDBC class 
 * which will enable MYSQL queries to be executed. It also has functions to provide the
 * returned data from the Queries. Currently the eventHandlers in QueryFrame call these
 * functions in order to run the Queries.
 */
public class QueryRunner {

    public QueryRunner()
    {
        this.m_jdbcData = new QueryJDBC();
        m_updateAmount = 0;
        m_queryArray = new ArrayList<>();
        m_error="";
        //TODO: Weston's Experiment Declaration
        //PrepareCall should make a CallableStatement
        //m_procedureArray = new ArrayList<>();
    
        
        // TODO - You will need to change the queries below to match your queries.
        
        // You will need to put your Project Application in the below variable
        
        //this.m_projectTeamApplication="CITYELECTION";    // THIS NEEDS TO CHANGE FOR YOUR APPLICATION
        this.m_projectTeamApplication="STUDENTBASKETBALL";
        
        // Each row that is added to m_queryArray is a separate query. It does not work on Stored procedure calls.
        // The 'new' Java keyword is a way of initializing the data that will be added to QueryArray. Please do not change
        // Format for each row of m_queryArray is: (QueryText, ParamaterLabelArray[], LikeParameterArray[], IsItActionQuery, IsItParameterQuery)
        
        //    QueryText is a String that represents your query. It can be anything but Stored Procedure
        //    Parameter Label Array  (e.g. Put in null if there is no Parameters in your query, otherwise put in the Parameter Names)
        //    LikeParameter Array  is an array I regret having to add, but it is necessary to tell QueryRunner which parameter has a LIKE Clause. If you have no parameters, put in null. Otherwise put in false for parameters that don't use 'like' and true for ones that do.
        //    IsItActionQuery (e.g. Mark it true if it is, otherwise false)
        //    IsItParameterQuery (e.g.Mark it true if it is, otherwise false)
//        m_queryArray.add(new QueryData("Select * from contact", null, null, false, false));   // THIS NEEDS TO CHANGE FOR YOUR APPLICATION
//        m_queryArray.add(new QueryData("Select * from contact where contact_id=?", new String [] {"CONTACT_ID"}, new boolean [] {false},  false, true));        // THIS NEEDS TO CHANGE FOR YOUR APPLICATION
//        m_queryArray.add(new QueryData("Select * from contact where contact_name like ?", new String [] {"CONTACT_NAME"}, new boolean [] {true}, false, true));        // THIS NEEDS TO CHANGE FOR YOUR APPLICATION
//        m_queryArray.add(new QueryData("insert into contact (contact_id, contact_name, contact_salary) values (?,?,?)",new String [] {"CONTACT_ID", "CONTACT_NAME", "CONTACT_SALARY"}, new boolean [] {false, false, false}, true, true));// THIS NEEDS TO CHANGE FOR YOUR APPLICATION

        ///////////////////////////////////////////////////////////////
        //                      TEAM 3 QUERIES                      //
        ///////////////////////////////////////////////////////////////

        //Weston's
        m_queryArray.add(new QueryData("SELECT a.AdministratorID, AdministratorName, AdministratorEmail, AdministratorPassword, LeagueID, LeagueName " +
                "FROM Administrator a JOIN League l ON (a.AdministratorID = l.AdministratorID) " +
                "WHERE LENGTH(AdministratorPassword) < ?", new String [] {"passwordLength"},  new boolean [] {false}, false, true));

        m_queryArray.add(new QueryData("SELECT p.PlayerID, PlayerName, AvgDefPlaysPerGame, DefensivePlaysGame1, WeekID  " +
                "FROM Player p JOIN PlayerRecord pr ON (p.PlayerID = pr.PlayerID)  " +
                "WHERE WeekID = ? AND DefensivePlaysGame1 >=  " +
                "(SELECT AVG(DefensivePlaysGame1)  FROM PlayerRecord pr2  WHERE pr2.WeekID = pr.WeekID) ORDER BY DefensivePlaysGame1 DESC, AvgDefPlaysPerGame DESC", new String [] {"weekChoice"}, new boolean [] {false}, false, true));
        //"(SELECT AVG(DefensivePlaysGame1)  FROM PlayerRecord pr2  WHERE WeekID = ?) ORDER BY DefensivePlaysGame1 DESC, AvgDefPlaysPerGame DESC"
        m_queryArray.add(new QueryData("SELECT TeacherID, TeacherName, TeacherEmail, d.LeagueID, AdministratorID " +
                "FROM Teacher t JOIN Draft d ON (t.LeagueID = d.LeagueID) WHERE DateOfDraft < ?", new String [] {"dateChoice"}, new boolean [] {false}, false, true));
        m_queryArray.add(new QueryData("SELECT u.UserID, u.UserName, u.UserEmail, t.TeamID, t.TeamName, pc.Points " +
                "FROM User u JOIN Team t ON (u.UserID = t.UserID) JOIN PointCollection pc " +
                "ON (u.UserID = pc.UserID) WHERE Points > ( SELECT AVG(Points) FROM PointCollection pc)" +
                "ORDER BY pc.Points DESC, u.UserID", null, null, false, false));
        //Maureen's
        m_queryArray.add(new QueryData("SELECT UserID, UserName, SUM(Points) as 'TotalPoints' " +
                "FROM  User NATURAL JOIN PointCollection " +
                "GROUP BY User.UserID " +
                "ORDER BY SUM(Points) DESC LIMIT 10 ", null, null, false, false));

        m_queryArray.add(new QueryData("SELECT PlayerId AS 'Lowest Scorers', PlayerName, PointsGame1 AS 'Points Scored' " +
                "FROM Player NATURAL JOIN PlayerRecord " +
                "WHERE PointsGame1 <= " +
                "(SELECT MIN(PointsGame1) " +
                "FROM PlayerRecord) " +
                "ORDER BY PlayerID ", null, null, false, false));
        m_queryArray.add(new QueryData("SELECT  Count(PlayerId) as 'Player Count',TeamID , TeamName, UserName, UserEmail " +
                "FROM Team_has_Player NATURAL JOIN Team NATURAL JOIN User " +
                "GROUP BY TeamID " +
                "HAVING Count(PlayerID) <> ? " +
                "ORDER BY UserName ", new String[] {"number of Players"}, new boolean []{false}, false, true ));
        m_queryArray.add(new QueryData("SELECT PlayerId AS 'MVPS', PlayerName, PointsGame1 AS 'Points Scored', DefensivePlaysGame1 AS 'Defensive Plays' " +
                "FROM Player NATURAL JOIN PlayerRecord WHERE PointsGame1 >= " +
                "(SELECT MAX(PointsGame1) FROM PlayerRecord) && DefensivePlaysGame1 >= " +
                "(SELECT MAX(DefensivePlaysGame1) FROM PlayerRecord) ORDER BY PlayerID ", null, null, false, false));

        //Kaiser's
        m_queryArray.add(new QueryData("SELECT t2.teacherID as 'Teacher with most students',count(u2.UserID) as 'Student Count' " +
                "FROM Teacher t2 JOIN User u2 ON t2.TeacherID = u2.TeacherID " +
                "GROUP BY t2.TeacherID " +
                "HAVING count(u2.UserID) >= ALL(SELECT count(u.UserID) as 'Student Count' FROM Teacher t, User u WHERE u.TeacherID = t.TeacherID GROUP BY t.TeacherID) ",
                null,null,false,false));

        m_queryArray.add(new QueryData("SELECT tea.teamID as 'id of team', tea.TeamName AS 'Team Name', " +
                "count(TradeID) as 'Count of trades' " +
                "from Trade t JOIN TradeWindow tr ON t.TradeWindowID = tr.TradeWindowID " +
                "JOIN User u ON u.UserID = t.UserID " +
                "JOIN Team tea ON tea.UserID = u.UserID " +
                "GROUP BY tea.TeamID " +
                "HAVING count(TradeID) >= ALL(SELECT count(TradeID) as 'Count of trades' from Trade t JOIN TradeWindow tr ON t.TradeWindowID = tr.TradeWindowID JOIN User u ON u.UserID = t.UserID JOIN Team tea ON tea.UserID = u.UserID GROUP BY tea.TeamID)",
                null,null,false,false));

        m_queryArray.add(new QueryData("SELECT p2.Points as Max , l2.LeagueID, l2.LeagueName, t2.TeamID, t2.TeamName " +
                "FROM PointCollection p2 " +
                "JOIN User u ON p2.UserID = u.UserID " +
                "JOIN Teacher t ON u.TeacherID = t.TeacherID " +
                "JOIN League l2 ON t.LeagueID = l2.LeagueID " +
                "JOIN Team t2 on t2.UserID = u.UserID " +
                "HAVING p2.points >= ALL(SELECT p.Points FROM PointCollection p JOIN User u2 ON p.UserID = u2.UserID JOIN Teacher t2 ON u2.TeacherID = t2.TeacherID JOIN League l ON t2.LeagueID = l.LeagueID JOIN Team t on t.UserID = u2.UserID WHERE l.LeagueID = l2.LeagueID GROUP BY l.LeagueID)",
                null,null,false,false));

    }
//    public void statementCaller()
//    {
//        try{
//            CallableStatement statement = con.prepareCall("call aboveAvgDefPlayers(?)");
//            Boolean hasResult = statement.executeStatement();
//
//        }
//        catch (SQLException){
//
//        }
//    }



    public int GetTotalQueries()
    {
        return m_queryArray.size();
    }
    
    public int GetParameterAmtForQuery(int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.GetParmAmount();
    }
              
    public String  GetParamText(int queryChoice, int parmnum )
    {
       QueryData e=m_queryArray.get(queryChoice);        
       return e.GetParamText(parmnum); 
    }   

    public String GetQueryText(int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.GetQueryString();        
    }
    
    /**
     * Function will return how many rows were updated as a result
     * of the update query
     * @return Returns how many rows were updated
     */
    
    public int GetUpdateAmount()
    {
        return m_updateAmount;
    }
    
    /**
     * Function will return ALL of the Column Headers from the query
     * @return Returns array of column headers
     */
    public String [] GetQueryHeaders()
    {
        return m_jdbcData.GetHeaders();
    }
    
    /**
     * After the query has been run, all of the data has been captured into
     * a multi-dimensional string array which contains all the row's. For each
     * row it also has all the column data. It is in string format
     * @return multi-dimensional array of String data based on the resultset 
     * from the query
     */
    public String[][] GetQueryData()
    {
        return m_jdbcData.GetData();
    }

    public String GetProjectTeamApplication()
    {
        return m_projectTeamApplication;        
    }
    public boolean  isActionQuery (int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.IsQueryAction();
    }
    
    public boolean isParameterQuery(int queryChoice)
    {
        QueryData e=m_queryArray.get(queryChoice);
        return e.IsQueryParm();
    }
    
     
    public boolean ExecuteQuery(int queryChoice, String [] parms)
    {
        boolean bOK = true;
        QueryData e=m_queryArray.get(queryChoice);        
        bOK = m_jdbcData.ExecuteQuery(e.GetQueryString(), parms, e.GetAllLikeParams());
        return bOK;
    }
    
     public boolean ExecuteUpdate(int queryChoice, String [] parms)
    {
        boolean bOK = true;
        QueryData e=m_queryArray.get(queryChoice);        
        bOK = m_jdbcData.ExecuteUpdate(e.GetQueryString(), parms);
        m_updateAmount = m_jdbcData.GetUpdateCount();
        return bOK;
    }   
    
      
    public boolean Connect(String szHost, String szUser, String szPass, String szDatabase)
    {

        boolean bConnect = m_jdbcData.ConnectToDatabase(szHost, szUser, szPass, szDatabase);
        if (bConnect == false)
            m_error = m_jdbcData.GetError();        
        return bConnect;
    }
    
    public boolean Disconnect()
    {
        // Disconnect the JDBCData Object
        boolean bConnect = m_jdbcData.CloseDatabase();
        if (bConnect == false)
            m_error = m_jdbcData.GetError();
        return true;
    }
    
    public String GetError()
    {
        return m_error;
    }
 
    private QueryJDBC m_jdbcData;
    private String m_error;    
    private String m_projectTeamApplication;
    private ArrayList<QueryData> m_queryArray;  
    private int m_updateAmount;
            
    /**
     * @param args the command line arguments
     */
    

    
    public static void main(String[] args) {
        // TODO code application logic here

        final QueryRunner queryrunner = new QueryRunner();

        if (args.length == 0) {
            java.awt.EventQueue.invokeLater(new Runnable() {
                public void run() {

                    new QueryFrame(queryrunner).setVisible(true);
                }
            });
        } else {
            if (args[0].equals("-console")) {
                System.out.println("Nothing has been implemented yet. Please implement the necessary code");
                // TODO
                // You should code the following functionality:

                //    You need to determine if it is a parameter query. If it is, then
                //    you will need to ask the user to put in the values for the Parameters in your query
                //    you will then call ExecuteQuery or ExecuteUpdate (depending on whether it is an action query or regular query)
                //    if it is a regular query, you should then get the data by calling GetQueryData. You should then display this
                //    output.
                //    If it is an action query, you will tell how many row's were affected by it.
                //
                //    This is Psuedo Code for the task:
                //    Connect()
                Scanner s = new Scanner(System.in);
                System.out.print("Enter the host name:");
                String hostName = s.nextLine();
                System.out.print("Enter the user name:");
                String userName = s.nextLine();
                System.out.print("Enter the password:");
                String password = s.nextLine();
                System.out.print("Enter the database:");
                String database = s.nextLine();
                boolean connection = queryrunner.Connect(hostName, userName, password, database);
                if (connection) {
                    //    n = GetTotalQueries()
                    //TODO: Ask user which query they want to run. We'll run one at a time but we may display all of them
                    int n = queryrunner.GetTotalQueries();
                    //    for (i=0;i < n; i++)
                    //    {
                    for (int i = 0; i < n; i++) {
                        //       Is it a query that Has Parameters
                        if (queryrunner.isParameterQuery(i)) {
                            //       Then
                            //           amt = find out how many parameters it has
                            int numParams = queryrunner.GetParameterAmtForQuery(i);
                            // Create a parameter array of strings for that amount
                            String[] params = new String[numParams];
                            //  for (j=0; j< amt; j++)
                            for (int j = 0; j < numParams; j++) {
                                // Get The Parameter Label for Query and print it to console. Ask the user to enter a value
                                System.out.print(queryrunner.GetParamText(i, j));
                                // Take the value you got and put it into your parameter array
                                params[j] = s.nextLine();
                            }
                            //           If it is an Action Query then
                            if (queryrunner.isActionQuery(i)) {
                                //              call ExecuteUpdate to run the Query
                                queryrunner.ExecuteUpdate(i, params);
                                //              call GetUpdateAmount to find out how many rows were affected, and print that value
                                int numUpdates = queryrunner.GetUpdateAmount();
                                System.out.println("The number of rows affected: " + numUpdates);
                            }
                            //           else
                            else {
                                //               call ExecuteQuery
                                queryrunner.ExecuteQuery(i, params);
                                //               call GetQueryData to get the results back
                                String[][] results = queryrunner.GetQueryData();
                                //               print out all the results
                                for (String[] row : results) {
                                    for (String elem : row) {
                                        System.out.print(elem + "  ");
                                    }
                                    System.out.println();
                                }
                            }
                            //           end if
                        }//end of if (parameter)

                        System.out.println("Enter 'y' to continue, 'n' to quit: ");
                        String quit = s.nextLine();
                        if(quit.equals("n"))//if user enters n
                            i = n;//reassign i so that loop stops executing
                    }//end of for loop(i)
                    //    Disconnect()
                    queryrunner.Disconnect();
                }//end if(connection)


                // NOTE - IF THERE ARE ANY ERRORS, please print the Error output
                // NOTE - The QueryRunner functions call the various JDBC Functions that are in QueryJDBC. If you would rather code JDBC
                // functions directly, you can choose to do that. It will be harder, but that is your option.
                // NOTE - You can look at the QueryRunner API calls that are in QueryFrame.java for assistance. You should not have to
                //    alter any code in QueryJDBC, QueryData, or QueryFrame to make this work.
//                System.out.println("Please write the non-gui functionality");

            }
        }

    }
}

